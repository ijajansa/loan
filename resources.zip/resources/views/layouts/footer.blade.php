<footer class="main-footer bg-dark" style="margin-left:auto;">
          <div class="row">
        <div class="col-md-3">
          <h3 class="text-warning">Hoogmatic</h3>
          <ul class="footer-ul">
                      <li class="nav-item"><a href="https://8tbt2ifc85wau6yu4664bkkllp69jd4wo2ox42b3n7h6u0ao5k4.hoogmatic.in" target="_blank" class="footer-list">Franchisee Login</a></li>
           
            <li class="nav-item"><a href="https://bcp.hoogmatic.in" target="_blank" class="footer-list">BCP Login</a></li>
          </ul>
        </div>
        <div class="col-md-3">
          <h3 class="text-warning">Hoog Money</h3>
          <ul class="footer-ul">
            <li class="nav-item"><a href="http://agent.hoogmatic.in/" target="_blank" class="footer-list">Agent Login</a></li>
            <li class="nav-item"><a href="http://distributor.hoogmatic.in/" target="_blank" class="footer-list">Distributor Login</a></li>
          </ul>  
        </div>
        <div class="col-md-3">
          <h3 class="text-warning">Loan Lenders</h3>
          <ul class="footer-ul">
            <li class="nav-item"><a href="https://connector.loanlenders.in" target="_blank" class="footer-list">Connector Login</a></li>
            <li class="nav-item"><a href="https://bcp.loanlenders.in" target="_blank" class="footer-list">BCP Login</a></li>
            <li class="nav-item"><a href="/index.php?path=promotion&method=categories" target="_blank" class="footer-list">Banners</a></li>
            <li class="nav-item"><a href="/index.php?path=dsa&method=certificate" class="footer-list">Certificate Download</a></li>
            <li class="nav-item"><a href="/index.php?path=dsa&method=authorisation" class="footer-list">Authorisation Letter Download</a></li>
          </ul>
        </div>
        <div class="col-md-3">
          <h3 class="text-warning">Quick Links</h3>
          <ul class="footer-ul">
            <li class="nav-item"><a href="https://hoogmatic.in/index.php/knowledge-base/" target="_blank" class="footer-list">Knowledg Base</a></li>
            <li class="nav-item"><a href="/index.php?path=home&method=tutorial" class="footer-list">Video Tutorials</a></li>
                        <li class="nav-item"><a href="https://media.hoogmatic.in/" class="footer-list" target="_blank">Media</a></li>
            <li class="nav-item"><a href="https://anydesk.com/en/downloads/thank-you?dv=win_exe" target="_blank" class="footer-list">Download AnyDesk</a></li>
          </ul>  
        </div>
      </div>
        <hr style="border-top: 1px solid rgb(227 227 227 / 50%);">
    <div class="row">
      <div class="col-md-12" style="font-size:12px;">
        <strong>Attention:</strong><br>
        HOOGMATIC OR LOAN LENDERS never asks any details related to debit cards and credit cards and Net Banking like CVV, OTP, SMS or any other highly confidential information. If an HOOGMATIC OR LOAN LENDERS customer receives any such mail or phone call, then they should understand that this is an online trick to steal their money. For any report, kindly email us at hello@hoogmatic.in
      </div>
    </div>
    <hr style="border-top: 1px solid rgb(227 227 227 / 50%);">
    <div class="row">
      <div class="col-md-12">
        <p style="font-size:13px">
          <i class="fas fa-map-marker-alt text-success"></i> &nbsp; <strong class="text-warning">Delhi</strong> <span>Head Office: H.NO-9&10 S/F, C-1 Blk, Rama Park, Uttam Nagar, New Delhi, Delhi: 110059 IN. Near Metro Station</span>
        </p>
        <p style="font-size:13px">
          <i class="fas fa-map-marker-alt text-success"></i> &nbsp; <strong  class="text-warning">Dehradun</strong> <span>Branch Office: 2nd floor , 15 A , Subhash Road Dehradun , 248001 , Near White House Hotel</span>
        </p>
        <p style="font-size:13px">
          <i class="fas fa-map-marker-alt text-success"></i> &nbsp; <strong  class="text-warning">Gujarat</strong> <span>Branch Office: E-105 , Swagat Flamingo , Swagat Holiday Mall , Near Sargasan Circle , Sargasan , Gandhinagar 382421</span>
        </p>
        <p style="font-size:13px">
          <i class="fas fa-map-marker-alt text-success"></i> &nbsp; <strong  class="text-warning">Patna</strong> <span>Branch Office: Leela Complex , Rukanpura Flyover , Bailey Road Patna , Bihar , 800014</span>
        </p> 
      </div>
    </div>
    <div class="row">
      <div class="col-12" style="font-size:12px;">
        Hoogmatic is present in more than 25 states of India- ANDHRA PRADESH | ASSAM | BIHAR | CHANDIGARH | CHHATTISGARH | DELHI | GUJARAT | HIMACHAL PRADESH | HARYANA | JHARKHAND | JAMMU AND KASHMIR | KARNATAKA | MAHARASHTRA | MADHYA PRADESH | ORISSA | PUNJAB | RAJASTHAN | SIKKIM | TAMIL NADU | TELANGANA | UTTARAKHAND | UTTAR PRADESH | WEST BENGAL. With lots of ❤ from Hoog Software Private Limited.
      </div>
    </div>
    <hr style="border-top: 1px solid rgb(227 227 227 / 50%);">
    <div class="row">
      <div class="col-6">
        <strong>Copyright &copy; 2019-2023 <a href="https://hoogmatic.in">Hoogmatic</a>.</strong> All rights reserved.
      </div>
      <div class="col-6">
      <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.1
      </div>
      </div>
    </div>
  </footer>